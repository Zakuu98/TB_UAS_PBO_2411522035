import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import java.util.ArrayList;

//interface
 interface Utama {
    void create ();
    void read();
    void update();
    void delete();
}

 class Aset {
    private int idAset;
    private String namaAset;
    private double hargaSewaPerHari;

    //constructor
    public Aset(int idAset, String namaAset, double hargaSewaPerHari) {
        this.idAset = idAset;
        this.namaAset = namaAset;
        this.hargaSewaPerHari = hargaSewaPerHari;
    }

    public double getHargaSewaPerHari() {
        return hargaSewaPerHari;
    }

    public String getNamaAset() {
        return namaAset.toUpperCase();
    }
}

// inheritance
 class Barang extends Aset {
    private String kondisi;

    //constructor
    public Barang(int id, String nama, double harga, String kondisi) {
        super(id, nama, harga);
        this.kondisi= kondisi;
    }

    public double ambilHarga() {
        return getHargaSewaPerHari(); // AMAN & BENAR
    }

}

 class Peminjaman {
    private Barang barang;
    private LocalDate tanggalPinjam;
    private LocalDate tanggalKembali;

    public Peminjaman(Barang barang, LocalDate pinjam, LocalDate kembali) {
        this.barang = barang;
        this.tanggalPinjam = pinjam;
        this.tanggalKembali = kembali;
    }

    public long hitungDurasi() {
        return ChronoUnit.DAYS.between(tanggalPinjam, tanggalKembali);
    }

    public double hitungTotalBiaya() {
        return hitungDurasi() * barang.ambilHarga();
    }
}

 class JDBCConnection {
    public static Connection getConnection() throws Exception {
        String url = "jdbc:mysql://localhost:3306/peminjaman";
        String user = "root";
        String pass = "";

        return DriverManager.getConnection(url, user, pass);
    }
}
// implementasi interface
 class BarangSewa implements Utama {

    @Override
    public void create() {
        try {
            Connection conn = JDBCConnection.getConnection();
            String sql = "INSERT INTO barang (nama, harga, kondisi) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "Speaker");
            ps.setDouble(2, 50000);
            ps.setString(3, "Baik");
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Gagal menambah barang: " + e.getMessage());
        }
    }

    @Override
    public void read() {
       // exception handling
        try {
        Connection conn = JDBCConnection.getConnection();
        Statement st = conn.createStatement();

        ResultSet rs = st.executeQuery("SELECT * FROM barang LIMIT 1");

        if (rs.next()) { // BUKAN while
            System.out.println(
                rs.getString("nama") + " | " +
                rs.getDouble("harga") + " | " +
                rs.getString("kondisi")
            );
        } else {
            System.out.println("Data barang kosong");
        }

    } catch (SQLException e) {
        System.out.println("SQL Error: " + e.getMessage());
    } catch (Exception e) {
        e.printStackTrace();
    }
    }

    @Override
    public void update() {
    }

    @Override
    public void delete() {
    }
}

 class MainApp {
    public static void main(String[] args) {

        // collection Framework
         ArrayList<Barang> daftarBarang = new ArrayList<>();
    
         Barang barang = new Barang(1, "Speaker", 50000, "Baik");
    daftarBarang.add(barang); // penggunaan collection

        Peminjaman pinjam = new Peminjaman(
                barang,
                LocalDate.of(2025, 1, 10),
                LocalDate.of(2025, 1, 13)
        );

        System.out.println("Barang: " + barang.getNamaAset());
        System.out.println("Durasi: " + pinjam.hitungDurasi() + " hari");
        System.out.println("Total Biaya: Rp " + pinjam.hitungTotalBiaya());

        BarangSewa service = new BarangSewa();
        service.create();
        service.read();
    }
}